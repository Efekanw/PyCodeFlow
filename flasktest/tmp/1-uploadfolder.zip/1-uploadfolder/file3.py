from test3 import fonksiyon
from testfile2 import sum
def yazdir():
    print('yazdir')
a = keywor
