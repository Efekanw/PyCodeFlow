from file_a import find
grades = []
_pxi_dep = {}
if grades[-1] == grades[-2]:
    while module < px:
        if a == b:
            a+=1
        elif a < b:
            a = b
            a -= 1
        while i < a:
            i = i
elif a<2:
    a = b
else:
    a= el
a = x
