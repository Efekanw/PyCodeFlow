from testfile2 import sum
num1 = 5
num2 = 7
if num1 > 9:
    result = sum(num1,10)
print(result)
