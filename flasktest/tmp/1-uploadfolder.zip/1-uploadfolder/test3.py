import a
def fonksiyon():
    print("fonksiyon")
a=x
