from s import f
from file3 import yazdir
from test3 import fonksiyon
def sum(n, n2):
    yazdir()
def subtract(n, n2):
    n -= n2
x, y = input(),  input()
b = 5
c = sum(a,b)
with open('filename.py', 'r') as file:
    str_file = file.read()
if c < 5:
    a = b
elif a == 1:
    for i in arr:
        print(i)
    print(2)
else:
    print(1)
a+=16
