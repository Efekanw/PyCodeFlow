from testfile2 import sum
from testfile2 import subtract
num1 = 5
num2 = 7
if num1 > num2:
    result = sum(num1,num2)
else:
    result = subtract(num2,num1)
print(result)
