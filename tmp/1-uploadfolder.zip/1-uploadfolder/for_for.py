_pxifiles = []
_pxi_dep = {}
test_string = 'test'
file_name = 'sub'
while module < px:
    for mod in module:
        for i in mod:
            if i==test_string:
                pxi_files = pjoin("pandas", x)
                _pxifiles.extend(pxi_files)
                _pxi_dep[module] = pxi_files
            elif i == file_name:
                print(file_name)
            else:
                index = 0
                while index <= len(_pxifiles):
                    index += 2
        if index == 8:
            index += 1
    while index < 9:
        index -= 1
        print(index)
index = 0
