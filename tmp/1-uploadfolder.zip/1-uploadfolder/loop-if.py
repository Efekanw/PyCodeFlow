_pxifiles = []
_pxi_dep = {}
while module in px:
    while i in x:
        if a==b:
            pxi_files = pjoin("pandas", x)
            _pxifiles.extend(pxi_files)
            _pxi_dep[module] = pxi_files
        elif a < b:
            a+=x
        for a in j:
            print('k')
a = b
