from testfile2 import sum
from setuptools import ( #
    Command,
    Extension,
    setup,
)
if x > 5:
    print('x > 5')
    for i in range(arr):
        x += i
else:
    print('invalid')
text = 'a'

