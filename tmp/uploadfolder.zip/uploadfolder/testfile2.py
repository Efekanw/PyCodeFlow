from s import f
def sum(n, n2):
    x = n + n2
    if x > 5:
        print('x greater than 5')
    elif x < 5:
        x += 5
    else:
        print('invalid')
x, y = input(),  input()
b = 5
c = sum(a,b)
with open('filename.py', 'r') as file:
    str_file = file.read()
if c < 5:
    a = b
elif a == 1:
    for i in arr:
        print(i)
    print(2)
else:
    print(1)
a+=16

